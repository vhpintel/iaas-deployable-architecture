## Samples

Contained in this directory are some simplistic Ansible playbooks that illustrate some basic techniques that may be 
built upon to construct more useful playbooks.  They are included here as samples only.
